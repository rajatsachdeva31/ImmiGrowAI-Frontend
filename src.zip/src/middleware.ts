import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

const publicRoutes = ['/', '/login', '/signup']

export async function middleware(request: NextRequest) {
  // Skip authentication check for public routes
  if (publicRoutes.includes(request.nextUrl.pathname)) {
    return NextResponse.next()
  }

  const endpoint = process.env.NEXT_PUBLIC_API_URL;
  
  try {
    const cookies = request.cookies;
    const tokenResponse = await fetch(`${endpoint}auth/token`, {
      credentials: 'include',
      headers: {
        Cookie: cookies.toString()
      }
    })
    
    if (!tokenResponse.ok) {
      return NextResponse.redirect(new URL('/login', request.url))
    }

    const tokenData = await tokenResponse.json()
    const token = tokenData.token

    if (!token) {
      return NextResponse.redirect(new URL('/', request.url))
    }

    // Add token to request headers
    const requestHeaders = new Headers(request.headers)
    requestHeaders.set('Authorization', `Bearer ${token}`)

    return NextResponse.next({
      request: {
        headers: requestHeaders,
      },
    })
  } catch {
    return NextResponse.redirect(new URL('/', request.url))
  }
}

export const config = {
  matcher: [
    '/dashboard/:path*',
    '/onboarding/:path*',
  ],
}
