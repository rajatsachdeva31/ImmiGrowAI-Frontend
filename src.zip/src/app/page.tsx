import Footer from "@/components/Footer";
import Header from "@/components/Header";

export default function Home() {
  return (
    <>
      <div className="flex flex-col min-h-screen min-w-full bg-background">
        <Header />
        <main className="w-full h-full">
          <div className="flex flex-col items-center justify-center gap-4 p-8">
            <h1 className="text-4xl font-bold text-center">
              Welcome to immigrateX
            </h1>
          </div>
        </main>
      </div>
      <Footer />
    </>
  );
}
