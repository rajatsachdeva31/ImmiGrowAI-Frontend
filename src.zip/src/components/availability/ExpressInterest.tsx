"use client";

import { useQuery, useMutation } from "@tanstack/react-query";
import { api } from "../utils/api";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { toast } from "react-toastify";

interface Props {
  type: "car" | "house";
  listingId: number;
}

const ExpressInterest: React.FC<Props> = ({ type, listingId }) => {
  const [selectedSlot, setSelectedSlot] = useState<number | null>(null);

  const { data: availability, isLoading } = useQuery({
    queryKey: ["expressInterest", type, listingId],
    queryFn: async () => {
      const res = await api.get("/express-interset", { params: { type, [`${type}ListingId`]: listingId } });
      return res.data;
    },
  });

  const bookSlot = useMutation({
    mutationFn: async (slotId: number) => api.post("/book", { slotId }),
    onSuccess: () => {
      toast.success("Slot booked successfully!");
    },
    onError: () => {
      toast.error("Error booking slot");
    },
  });

  if (isLoading) return <p>Loading...</p>;

  return (
    <div>
      <h3 className="text-lg font-semibold">Available Slots</h3>
      <ul>
        {availability?.map((slot: any) => (
          <li key={slot.id} className="border p-2 mb-2">
            <p>Start: {slot.startTime}</p>
            <p>End: {slot.endTime}</p>
            <Button className="bg-green-600 hover:bg-green-500 w-full mb-4" onClick={() => setSelectedSlot(slot.id)}>
              Select
            </Button>
          </li>
        ))}
      </ul>

      {selectedSlot && (
        <Button className="bg-blue-600 hover:bg-blue-500 w-full mb-4" onClick={() => bookSlot.mutate(selectedSlot)}>
          Confirm Booking
        </Button>
      )}
    </div>
  );
};

export default ExpressInterest;
