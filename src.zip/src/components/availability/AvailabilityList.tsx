"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "../utils/api";
import { toast } from "react-toastify";
import { Button } from "@/components/ui/button";
import AvailabilityForm from "./AvailabilityForm";
import { useState } from "react";

interface Availability {
  id: number;
  startTime: string;
  endTime: string;
  status: string;
  role: "realtor" | "carDealer" | "immigrationConsultant";
}

interface Props {
  role: Availability["role"];
}

const AvailabilityList: React.FC<Props> = ({ role }) => {
  const [editData, setEditData] = useState<Availability | null>(null);
  const queryClient = useQueryClient();

  const { data: availability, isLoading, error } = useQuery({
    queryKey: ["availability", role],
    queryFn: async () => {
      const res = await api.get(`/byId?role=${role}`);
      return res.data;
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => api.delete(`/delete/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries(["availability", role]);
      toast.success("Deleted successfully!");
    },
    onError: () => {
      toast.error("Error deleting availability");
    },
  });

  if (isLoading) return <p>Loading...</p>;
  if (error) return <p>Error fetching availability.</p>;

  return (
    <div>
      <h2 className="text-xl font-semibold">{role} Availability</h2>

      <Button className="bg-green-600 hover:bg-green-500 w-full mb-4" onClick={() => setEditData(null)}>
        Add Availability
      </Button>

      {editData && <AvailabilityForm existingData={editData} role={role} onClose={() => setEditData(null)} />}

      <ul>
        {availability?.map((slot: Availability) => (
          <li key={slot.id} className="border p-2 mb-2">
            <p>Start: {slot.startTime}</p>
            <p>End: {slot.endTime}</p>

            <Button className="bg-green-600 hover:bg-green-500 w-full mb-4" onClick={() => setEditData(slot)}>
              Edit
            </Button>

            <Button className="bg-red-600 hover:bg-red-500 w-full mb-4" onClick={() => deleteMutation.mutate(slot.id)}>
              Delete
            </Button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AvailabilityList;
