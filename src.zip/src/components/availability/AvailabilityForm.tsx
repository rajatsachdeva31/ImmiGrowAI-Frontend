"use client";

import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { api } from "../utils/api";
import { toast } from "react-toastify";
import { Button } from "@/components/ui/button";

interface Availability {
  id?: number;
  startTime: string;
  endTime: string;
  status: string;
  role: "realtor" | "carDealer" | "immigrationConsultant";
}

interface Props {
  existingData?: Availability;
  role: Availability["role"];
  onClose: () => void;
}

const AvailabilityForm: React.FC<Props> = ({ existingData, role, onClose }) => {
  const queryClient = useQueryClient();
  const { register, handleSubmit } = useForm<Availability>({
    defaultValues: existingData || { startTime: "", endTime: "", status: "Available", role },
  });

  const mutation = useMutation({
    mutationFn: async (data: Availability) => {
      return existingData ? api.put(`/update/${existingData.id}`, data) : api.post("/add", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["availability", role]);
      toast.success(existingData ? "Updated successfully!" : "Added successfully!");
      onClose();
    },
    onError: () => {
      toast.error("Error saving availability");
    },
  });

  return (
    <form onSubmit={handleSubmit((data) => mutation.mutate(data))} className="p-4 border rounded">
      <label>Start Time:</label>
      <input type="datetime-local" {...register("startTime")} required className="block mb-2" />

      <label>End Time:</label>
      <input type="datetime-local" {...register("endTime")} required className="block mb-2" />

      <Button type="submit" className="bg-green-600 hover:bg-green-500 w-full mb-4">
        {existingData ? "Update" : "Add"}
      </Button>
    </form>
  );
};

export default AvailabilityForm;
